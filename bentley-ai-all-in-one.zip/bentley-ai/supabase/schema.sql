-- Run this file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.video_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  prompt text not null check (char_length(prompt) between 8 and 1800),
  image_url text,
  provider_prediction_id text not null,
  status text not null default 'starting',
  video_url text,
  error_message text,
  created_at timestamptz not null default now()
);

alter table public.video_jobs enable row level security;

create policy "Users can read their own video jobs"
on public.video_jobs for select to authenticated
using (auth.uid() = user_id);

create policy "Users can insert their own video jobs"
on public.video_jobs for insert to authenticated
with check (auth.uid() = user_id);

create policy "Users can update their own video jobs"
on public.video_jobs for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- Create a Storage bucket named "references" in the Supabase dashboard.
-- Set it to PRIVATE for production and replace public URLs with signed URLs.
-- Storage object policies:
create policy "Users upload reference images"
on storage.objects for insert to authenticated
with check (bucket_id = 'references' and (storage.foldername(name))[1] is null);

create policy "Authenticated users can read reference images"
on storage.objects for select to authenticated
using (bucket_id = 'references');

-- Create a public Storage bucket named "assets" for generated voice-over and music.
-- For production, use a private bucket and signed URLs instead.
create policy "Users upload their own audio assets"
on storage.objects for insert to authenticated
with check (bucket_id = 'assets' and (storage.foldername(name))[1] = 'audio');

create policy "Authenticated users can read audio assets"
on storage.objects for select to authenticated
using (bucket_id = 'assets');


create table if not exists public.video_renders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider_render_id text not null unique,
  status text not null default 'queued',
  video_url text,
  created_at timestamptz not null default now()
);
alter table public.video_renders enable row level security;
create policy "Users can read their own renders" on public.video_renders
for select to authenticated using (auth.uid() = user_id);
create policy "Users can insert their own renders" on public.video_renders
for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update their own renders" on public.video_renders
for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
