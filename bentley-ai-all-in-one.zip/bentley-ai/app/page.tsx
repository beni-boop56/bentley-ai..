import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Studio from "@/components/studio";
export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  return <Studio email={user.email ?? ""} />;
}
