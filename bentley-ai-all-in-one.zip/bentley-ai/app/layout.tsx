import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Bentley AI — Create cinematic videos",
  description: "Turn prompts and image references into vertical AI videos."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
