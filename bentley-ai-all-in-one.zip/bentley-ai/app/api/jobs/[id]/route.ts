import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export const runtime = "nodejs";
export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;
  const { data: job, error } = await supabase.from("video_jobs").select("*").eq("id", id).eq("user_id", user.id).single();
  if (error || !job) return NextResponse.json({ error: "Job not found." }, { status: 404 });
  if (["succeeded","failed","canceled"].includes(job.status)) return NextResponse.json({ job });
  const token = process.env.REPLICATE_API_TOKEN;
  const providerResponse = await fetch(`https://api.replicate.com/v1/predictions/${job.provider_prediction_id}`, { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" });
  const prediction = await providerResponse.json();
  if (!providerResponse.ok) return NextResponse.json({ error: "Could not check provider status." }, { status: 502 });
  const output = Array.isArray(prediction.output) ? prediction.output[0] : prediction.output;
  const videoUrl = prediction.status === "succeeded" && typeof output === "string" ? output : null;
  const { data: updated, error: updateError } = await supabase.from("video_jobs").update({
    status: prediction.status, video_url: videoUrl, error_message: prediction.error ? String(prediction.error).slice(0,1000) : null
  }).eq("id", id).eq("user_id", user.id).select("*").single();
  if (updateError) return NextResponse.json({ error: "Could not update job." }, { status: 500 });
  return NextResponse.json({ job: updated });
}
