import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export const runtime = "nodejs";

type Scene = { number:number; title:string; description:string; visual_prompt:string; narration:string };
export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error:"Unauthorized" }, { status:401 });
  const body = await request.json().catch(()=>null);
  const idea = typeof body?.idea === "string" ? body.idea.trim() : "";
  const sceneCount = Number(body?.sceneCount);
  if (idea.length < 8 || idea.length > 1800) return NextResponse.json({error:"Story idea must be between 8 and 1800 characters."},{status:400});
  if (!Number.isInteger(sceneCount) || sceneCount < 3 || sceneCount > 6) return NextResponse.json({error:"Choose between 3 and 6 scenes."},{status:400});
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return NextResponse.json({error:"Story planner is not configured. Add OPENAI_API_KEY to the server environment."},{status:503});
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method:"POST",
    headers:{Authorization:`Bearer ${apiKey}`,"Content-Type":"application/json"},
    body:JSON.stringify({
      model:process.env.OPENAI_STORY_MODEL || "gpt-4.1-mini",
      response_format:{type:"json_object"},
      messages:[
        {role:"system",content:"You are a professional short-form film story planner. Return valid JSON only with keys title, logline, scenes. scenes must contain exactly the requested number of objects with number, title, description, visual_prompt, narration. Make scenes form one coherent story with a clear beginning, middle and ending. Keep the main character's appearance and identity consistent in every visual_prompt. Visual prompts must be suitable for a vertical 9:16 short video, describe one visually coherent shot, camera movement, lighting and setting. Do not ask the video model to render text. Keep each visual_prompt concise and production-ready. narration should be a short optional voiceover line."},
        {role:"user",content:`Create exactly ${sceneCount} connected scenes for this idea: ${idea}`}
      ],
      temperature:0.7
    })
  });
  const result = await response.json();
  if (!response.ok) return NextResponse.json({error:result.error?.message || "Story planning provider error."},{status:502});
  try {
    const content = result.choices?.[0]?.message?.content;
    const story = JSON.parse(content);
    if (typeof story.title !== "string" || !Array.isArray(story.scenes) || story.scenes.length !== sceneCount) throw new Error("Invalid story format");
    const scenes:Scene[] = story.scenes.map((s:Record<string,unknown>,i:number)=>({
      number:i+1,
      title:String(s.title || `Scene ${i+1}`).slice(0,120),
      description:String(s.description || "").slice(0,600),
      visual_prompt:String(s.visual_prompt || "").slice(0,1500),
      narration:String(s.narration || "").slice(0,400)
    }));
    return NextResponse.json({story:{title:String(story.title).slice(0,160),logline:String(story.logline || "").slice(0,500),scenes}});
  } catch {
    return NextResponse.json({error:"The story planner returned an invalid story. Please try again."},{status:502});
  }
}
