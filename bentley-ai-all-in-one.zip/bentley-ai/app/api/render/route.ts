import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json().catch(() => null);
  const ids = Array.isArray(body?.jobIds) ? body.jobIds.filter((id: unknown) => typeof id === "string").slice(0, 12) : [];
  if (!ids.length) return NextResponse.json({ error: "Choose at least one completed video clip." }, { status: 400 });

  const { data: jobs, error } = await supabase.from("video_jobs").select("id,video_url,status").eq("user_id", user.id).in("id", ids);
  if (error || !jobs || jobs.length !== ids.length) return NextResponse.json({ error: "Some selected clips could not be found." }, { status: 404 });
  if (jobs.some(job => job.status !== "succeeded" || !job.video_url)) return NextResponse.json({ error: "All selected clips must be completed before assembly." }, { status: 400 });

  const apiKey = process.env.SHOTSTACK_API_KEY;
  if (!apiKey) return NextResponse.json({ error: "Final MP4 assembly needs SHOTSTACK_API_KEY in the server environment." }, { status: 503 });
  const stage = process.env.SHOTSTACK_ENV === "production" ? "v1" : "stage";
  const clips = jobs.map((job, index) => ({
    asset: { type: "video", src: job.video_url },
    start: index * 5,
    length: 5,
    fit: "crop",
    scale: 1
  }));
  const tracks: Array<{ clips: unknown[] }> = [{ clips }];
  if (typeof body?.audioUrl === "string" && body.audioUrl.startsWith(process.env.NEXT_PUBLIC_SUPABASE_URL + "/storage/")) {
    tracks.push({ clips: [{ asset: { type: "audio", src: body.audioUrl }, start: 0, length: "end", volume: 1 }] });
  }
  if (typeof body?.backgroundUrl === "string" && body.backgroundUrl.startsWith(process.env.NEXT_PUBLIC_SUPABASE_URL + "/storage/")) {
    tracks.push({ clips: [{ asset: { type: "audio", src: body.backgroundUrl }, start: 0, length: "end", volume: 0.18 }] });
  }
  const captions = typeof body?.captions === "string" ? body.captions.trim().slice(0, 500) : "";
  if (captions) {
    tracks.push({ clips: [{
      asset: { type: "title", text: captions, style: "minimal", position: "bottom" },
      start: 0, length: jobs.length * 5
    }] });
  }

  const response = await fetch(`https://api.shotstack.io/edit/${stage}/render`, {
    method: "POST",
    headers: { "x-api-key": apiKey, "Content-Type": "application/json" },
    body: JSON.stringify({
      timeline: { background: "#000000", tracks, soundtrack: undefined },
      output: { format: "mp4", resolution: "hd", aspectRatio: body?.aspectRatio === "16:9" ? "16:9" : body?.aspectRatio === "1:1" ? "1:1" : "9:16" }
    })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) return NextResponse.json({ error: result?.response?.message || result?.message || "Render provider rejected the request." }, { status: 502 });
  const renderId = result?.response?.id;
  if (!renderId) return NextResponse.json({ error: "Render provider did not return a render ID." }, { status: 502 });
  const { error: saveError } = await supabase.from("video_renders").insert({ user_id: user.id, provider_render_id: renderId, status: result?.response?.status || "queued" });
  if (saveError) return NextResponse.json({ error: "Render started, but its history could not be saved." }, { status: 500 });
  return NextResponse.json({ renderId, statusUrl: `/api/render/${renderId}` }, { status: 202 });
}
