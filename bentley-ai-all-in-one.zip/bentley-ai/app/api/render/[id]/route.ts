import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;
  const { data: render, error: renderError } = await supabase.from("video_renders").select("provider_render_id").eq("provider_render_id", id).eq("user_id", user.id).single();
  if (renderError || !render) return NextResponse.json({ error: "Render not found." }, { status: 404 });
  const apiKey = process.env.SHOTSTACK_API_KEY;
  if (!apiKey) return NextResponse.json({ error: "Render provider is not configured." }, { status: 503 });
  const response = await fetch(`https://api.shotstack.io/edit/${process.env.SHOTSTACK_ENV === "production" ? "v1" : "stage"}/render/${encodeURIComponent(id)}`, {
    headers: { "x-api-key": apiKey }, cache: "no-store"
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) return NextResponse.json({ error: "Could not retrieve render status." }, { status: 502 });
  await supabase.from("video_renders").update({ status: data?.response?.status || "unknown", video_url: data?.response?.url || null }).eq("provider_render_id", id).eq("user_id", user.id);
  return NextResponse.json({ status: data?.response?.status, url: data?.response?.url, error: data?.response?.error });
}
