import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json().catch(() => null);
  const text = typeof body?.text === "string" ? body.text.trim() : "";
  const allowed = ["alloy", "coral", "echo", "fable", "onyx", "nova", "shimmer"];
  const voice = allowed.includes(body?.voice) ? body.voice : "alloy";
  if (text.length < 2 || text.length > 4000) {
    return NextResponse.json({ error: "Voice-over text must be between 2 and 4000 characters." }, { status: 400 });
  }
  const key = process.env.OPENAI_API_KEY;
  if (!key) return NextResponse.json({ error: "Add OPENAI_API_KEY to enable AI voice-over." }, { status: 503 });

  const response = await fetch("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: process.env.OPENAI_TTS_MODEL || "gpt-4o-mini-tts", voice, input: text, response_format: "mp3" })
  });
  if (!response.ok) {
    const detail = await response.text();
    return NextResponse.json({ error: detail.slice(0, 500) || "Voice provider error." }, { status: 502 });
  }
  return new Response(await response.arrayBuffer(), { headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" } });
}
