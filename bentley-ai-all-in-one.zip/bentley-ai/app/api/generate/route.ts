import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export const runtime = "nodejs";
const MAX_PROMPT = 1800;
export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await request.json().catch(() => null);
  const prompt = typeof body?.prompt === "string" ? body.prompt.trim() : "";
  const imageUrl = typeof body?.imageUrl === "string" ? body.imageUrl : null;
  if (prompt.length < 8 || prompt.length > MAX_PROMPT) return NextResponse.json({ error: "Prompt must be between 8 and 1800 characters." }, { status: 400 });
  if (imageUrl && !imageUrl.startsWith(process.env.NEXT_PUBLIC_SUPABASE_URL + "/storage/")) return NextResponse.json({ error: "Invalid reference image URL." }, { status: 400 });
  const token = process.env.REPLICATE_API_TOKEN;
  const version = process.env.REPLICATE_MODEL_VERSION;
  if (!token || !version || version === "YOUR_MODEL_VERSION_ID") return NextResponse.json({ error: "Video provider is not configured. Add a compatible Replicate model version to the server environment." }, { status: 503 });
  const promptField = process.env.VIDEO_PROMPT_FIELD || "prompt";
  const imageField = process.env.VIDEO_IMAGE_FIELD || "image";
  const input: Record<string, unknown> = { [promptField]: prompt };
  if (imageUrl) input[imageField] = imageUrl;
  const providerResponse = await fetch("https://api.replicate.com/v1/predictions", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ version, input })
  });
  const prediction = await providerResponse.json();
  if (!providerResponse.ok) return NextResponse.json({ error: prediction.detail || "Video provider rejected the request." }, { status: 502 });
  const { data, error } = await supabase.from("video_jobs").insert({
    user_id: user.id, prompt, image_url: imageUrl, provider_prediction_id: prediction.id,
    status: prediction.status || "starting"
  }).select("id,status").single();
  if (error) return NextResponse.json({ error: "Could not save generation job." }, { status: 500 });
  return NextResponse.json({ job: data }, { status: 201 });
}
