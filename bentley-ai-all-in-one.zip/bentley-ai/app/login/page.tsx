import AuthForm from "@/components/auth-form";
export default function LoginPage() { return <main className="min-h-screen grid place-items-center p-5"><AuthForm /></main>; }
