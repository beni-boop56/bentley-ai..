# Bentley AI — MVP

A Next.js starter for a prompt + image-reference to vertical AI video studio.

## What is included

- Email/password authentication with Supabase Auth
- Responsive dark studio UI
- Image reference upload to Supabase Storage
- Story Mode: AI-generated connected scene plans (3–6 scenes)\n- Sequential submission of scene prompts to Replicate\n- Video generation job creation through Replicate
- Per-user generation history with Row Level Security
- Job status polling and video preview/download

## 1. Requirements

- Node.js 20.9+
- A Supabase project
- A Replicate account, an image-to-video model, and (for final assembly) a Shotstack account

## 2. Install

```bash
npm install
cp .env.example .env.local
```

Fill `.env.local` with your Supabase project URL and anon key, service role key (server-side only), Replicate API token and a compatible model version ID. Add an OpenAI API key to enable Story Mode planning.

**Never put `SUPABASE_SERVICE_ROLE_KEY` or `REPLICATE_API_TOKEN` in a `NEXT_PUBLIC_` variable. Never commit `.env.local`.**

## 3. Configure Supabase

1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql` (including the `video_renders` history table).
3. In Storage, create a bucket named `references`.
4. Create `references` as a public bucket for the MVP so the video provider can fetch the reference image URL.
5. Create a second public bucket named `assets` for generated voice-over and uploaded background music. The SQL policies below assume this bucket exists. This is convenient but not ideal for private user photos.
5. In Authentication > URL Configuration, set the local site URL to `http://localhost:3000` and add your deployed URL later.
6. Enable email/password authentication.

For production, make the bucket private, generate short-lived signed URLs on the server, and pass those to the model. Review storage policies and add file scanning/rate limits.

## 4. Configure video generation

Replicate hosts many models, and their input schemas differ. Choose a model version that explicitly supports image-to-video or reference-image conditioning.

Set:
- `REPLICATE_API_TOKEN`
- `REPLICATE_MODEL_VERSION` to the exact version ID
- `VIDEO_PROMPT_FIELD` to the model's prompt input property (often `prompt`)
- `VIDEO_IMAGE_FIELD` to the model's image input property (could be `image`, `image_url`, `first_frame`, etc.)

This starter submits the prompt and optional image to Replicate's Predictions API. It does not assume a particular model schema. Check the selected model's documentation for required aspect-ratio, duration, safety, and output parameters. If the model returns an array of output URLs, the first URL is used in this MVP.

## Story Mode\n\nStory Mode calls the OpenAI Chat Completions API to create a structured story plan of 3–6 scenes. It then submits each scene as a separate Replicate video prediction, reusing the uploaded image reference. The MVP does not stitch those clips into one final MP4 yet; users can preview each generated scene independently. A production release should add a server-side queue, provider webhooks, retry handling, and a video-rendering step (for example with FFmpeg) to join clips.\n\n## 6. Run

```bash
npm run dev
```

Open http://localhost:3000.

## 7. Production hardening before launch

- Use a private storage bucket and server-generated signed URLs.
- Add webhook-based completion instead of relying only on browser polling.
- Persist provider output metadata and copy generated videos into controlled storage; provider output URLs may expire.
- Add per-user quotas, billing, request rate limits, and abuse prevention.
- Validate MIME type and actual image content server-side; enforce upload size limits server-side.
- Add deletion/export controls and a privacy policy.
- Add moderation and rights checks for uploaded images and prompts.
- Add automated tests, error monitoring, and backups.
- Add a model-specific adapter for every supported video model.

## Architecture

`Browser -> Next.js App Router -> Supabase Auth/DB/Storage -> Replicate Predictions API`

The API token remains on the server. Row Level Security restricts video job records to their owner.

## All-in-one production tools

The studio now includes:
- Single-video and Story Mode creation
- Character/object image references
- Voice-over generation through OpenAI text-to-speech
- Voice selection and audio preview
- Optional background music upload
- Caption/title text input
- Aspect-ratio selection (9:16, 16:9, 1:1)
- Final MP4 assembly request through Shotstack
- Per-user job history and previews

Configure `OPENAI_API_KEY` for story planning and voice-over, plus `SHOTSTACK_API_KEY` for final MP4 assembly. The render adapter currently places each selected clip on a five-second timeline slot; adjust clip lengths to match the exact output durations of your chosen video model before production. Shotstack stage is used by default. Review Shotstack's current API and plan limits before deployment.

The current MVP sends finished scene clips to the renderer and can add one voice track, one music track, and a title/caption overlay. It does not yet provide frame-accurate timeline trimming, word-level animated subtitles, or persistent render history. Add those before presenting this as a professional production release.
