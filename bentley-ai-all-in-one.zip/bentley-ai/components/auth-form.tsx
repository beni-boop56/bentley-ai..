"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Sparkles } from "lucide-react";
export default function AuthForm() {
  const [email,setEmail] = useState(""); const [password,setPassword] = useState("");
  const [mode,setMode] = useState<"signin"|"signup">("signin");
  const [message,setMessage] = useState(""); const [busy,setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    const supabase = createClient();
    const result = mode === "signin"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password });
    setBusy(false);
    if (result.error) setMessage(result.error.message);
    else if (mode === "signup") setMessage("Check your email to confirm your account, then sign in.");
    else window.location.href = "/";
  }
  return <form onSubmit={submit} className="glass w-full max-w-md rounded-3xl p-8 space-y-5">
    <div className="flex items-center gap-3"><div className="rounded-xl bg-red-600 p-3"><Sparkles /></div><div><h1 className="text-2xl font-black">BENTLEY AI</h1><p className="text-xs text-zinc-400">YOUR AI VIDEO STUDIO</p></div></div>
    <div><h2 className="text-xl font-bold">{mode==="signin"?"Welcome back":"Create your account"}</h2><p className="text-sm text-zinc-400">Sign in to create and save your videos.</p></div>
    <input className="field" type="email" required placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)} />
    <input className="field" type="password" required minLength={8} placeholder="Password (at least 8 characters)" value={password} onChange={e=>setPassword(e.target.value)} />
    {message && <p className="text-sm text-red-300">{message}</p>}
    <button disabled={busy} className="btn btn-primary w-full">{busy?"Please wait…":mode==="signin"?"Sign in":"Create account"}</button>
    <button type="button" className="w-full text-sm text-zinc-400 hover:text-white" onClick={()=>{setMode(mode==="signin"?"signup":"signin");setMessage("");}}>{mode==="signin"?"New to Bentley AI? Create an account":"Already registered? Sign in"}</button>
  </form>;
}
