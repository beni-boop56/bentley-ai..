"use client";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Film, ImagePlus, Loader2, LogOut, Sparkles, WandSparkles, Download, Clapperboard, Music2, Captions, AudioLines, Scissors, Layers, Smartphone } from "lucide-react";
type Job = { id:string; prompt:string; status:string; video_url:string|null; created_at:string };
export default function Studio({ email }: { email:string }) {
  const [prompt,setPrompt]=useState(""); const [file,setFile]=useState<File|null>(null);
  const [mode,setMode]=useState<"single"|"story">("single");
  const [sceneCount,setSceneCount]=useState(4);
  const [story,setStory]=useState<{title:string;logline:string;scenes:{number:number;title:string;description:string;visual_prompt:string;narration:string}[]}|null>(null);
  const [storyBusy,setStoryBusy]=useState(false);
  const [voice,setVoice]=useState("alloy");
  const [voiceBusy,setVoiceBusy]=useState(false);
  const [voiceUrl,setVoiceUrl]=useState("");
  const [musicFile,setMusicFile]=useState<File|null>(null);
  const [musicUrl,setMusicUrl]=useState("");
  const [captionText,setCaptionText]=useState("");
  const [aspectRatio,setAspectRatio]=useState("9:16");
  const [renderBusy,setRenderBusy]=useState(false);
  const [renderMessage,setRenderMessage]=useState("");
  const [renderUrl,setRenderUrl]=useState("");
  const [renderId,setRenderId]=useState("");
  const [preview,setPreview]=useState(""); const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState(""); const [jobs,setJobs]=useState<Job[]>([]);
  const supabase=createClient();
  async function loadJobs() {
    const {data}=await supabase.from("video_jobs").select("*").order("created_at",{ascending:false}).limit(20);
    if(data) setJobs(data as Job[]);
  }
  useEffect(()=>{ loadJobs(); },[]);
  useEffect(()=>{ if(!file){setPreview("");return;} const url=URL.createObjectURL(file);setPreview(url);return()=>URL.revokeObjectURL(url); },[file]);
  async function generate(e:React.FormEvent) {
    e.preventDefault(); setBusy(true);setMessage("");
    try {
      let imageUrl:string|undefined;
      if(file) {
        const ext=file.name.split(".").pop()?.toLowerCase() || "jpg";
        const path=`${crypto.randomUUID()}.${ext}`;
        const {error:uploadError}=await supabase.storage.from("references").upload(path,file,{upsert:false,contentType:file.type});
        if(uploadError) throw uploadError;
        const {data}=supabase.storage.from("references").getPublicUrl(path);
        imageUrl=data.publicUrl;
      }
      const response=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt,imageUrl})});
      const body=await response.json();
      if(!response.ok) throw new Error(body.error||"Could not start generation.");
      setMessage("Generation started. Video jobs can take several minutes.");
      setPrompt("");setFile(null);await loadJobs();
    } catch(err) { setMessage(err instanceof Error?err.message:"Something went wrong."); }
    finally { setBusy(false); }
  }
  async function refreshJob(id:string) {
    const r=await fetch(`/api/jobs/${id}`);const d=await r.json();
    if(r.ok) setJobs(old=>old.map(j=>j.id===id?d.job:j));
  }
  async function signOut(){await supabase.auth.signOut();window.location.href="/login";}
  return <main className="min-h-screen">
    <header className="border-b border-zinc-800 bg-black/70"><div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
      <div className="flex items-center gap-3"><div className="rounded-xl bg-red-600 p-2"><Sparkles size={20}/></div><div><div className="font-black tracking-wider">BENTLEY AI</div><div className="text-[10px] tracking-[.25em] text-zinc-500">VIDEO CREATION STUDIO</div></div></div>
      <div className="flex items-center gap-3"><span className="hidden text-xs text-zinc-400 sm:block">{email}</span><button onClick={signOut} className="text-zinc-400 hover:text-white" aria-label="Sign out"><LogOut size={18}/></button></div>
    </div></header>
    <div className="mx-auto grid max-w-6xl gap-8 px-5 py-10 lg:grid-cols-[1.1fr_.9fr]">
      <section className="space-y-6">
        <div><div className="mb-3 inline-flex items-center gap-2 rounded-full border border-red-900 bg-red-950/40 px-3 py-1 text-xs text-red-300"><WandSparkles size={14}/> TEXT + IMAGE TO VIDEO</div><h1 className="text-4xl font-black leading-tight sm:text-5xl">Make your ideas<br/><span className="text-red-500">move.</span></h1><p className="mt-3 max-w-lg text-zinc-400">Describe a scene, add a visual reference, and create a vertical video for your social channels.</p></div>
        <div className="flex gap-2 rounded-2xl border border-zinc-800 bg-black/30 p-1">
          <button type="button" onClick={()=>setMode("single")} className={`flex-1 rounded-xl px-3 py-2 text-sm font-semibold ${mode==="single"?"bg-red-600 text-white":"text-zinc-400 hover:text-white"}`}>Single video</button>
          <button type="button" onClick={()=>setMode("story")} className={`flex-1 rounded-xl px-3 py-2 text-sm font-semibold ${mode==="story"?"bg-red-600 text-white":"text-zinc-400 hover:text-white"}`}>Story mode</button>
        </div>
        <form onSubmit={mode==="single"?generate:async(e)=>{e.preventDefault();setStoryBusy(true);setMessage("");try{let imageUrl:string|undefined;if(file){const ext=file.name.split(".").pop()?.toLowerCase()||"jpg";const path=`${crypto.randomUUID()}.${ext}`;const {error}=await supabase.storage.from("references").upload(path,file,{upsert:false,contentType:file.type});if(error)throw error;imageUrl=supabase.storage.from("references").getPublicUrl(path).data.publicUrl;}const planResponse=await fetch("/api/story-plan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idea:prompt,sceneCount})});const planBody=await planResponse.json();if(!planResponse.ok)throw new Error(planBody.error||"Could not create story plan.");setStory(planBody.story);let started=0;for(const scene of planBody.story.scenes){const r=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:`Story: ${planBody.story.title}. Overall story: ${planBody.story.logline}. Scene ${scene.number}: ${scene.title}. ${scene.visual_prompt}. Maintain the same character identity and visual style as the reference image. ${aspectRatio} cinematic video.`,imageUrl})});const d=await r.json();if(!r.ok)throw new Error(d.error||`Scene ${scene.number} could not be started.`);started++;}setMessage(`Story created. ${started} scene video jobs have been submitted. Refresh the creations list to check their progress.`);await loadJobs();}catch(err){setMessage(err instanceof Error?err.message:"Story generation failed.");}finally{setStoryBusy(false);}}} className="glass space-y-5 rounded-3xl p-5 sm:p-7">
          <div><label className="mb-2 block text-sm font-semibold">{mode==="story"?"Describe your story":"Describe your video"}</label><textarea className="field min-h-36 resize-y" required minLength={8} maxLength={1800} value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder={mode==="story"?"Example: A small robot finds a lost kitten in a futuristic city and helps it get home. Keep the same robot design throughout.":"Example: A tiny astronaut explores a glowing forest at night. Cinematic camera movement, magical atmosphere, detailed lighting…"}/><div className="mt-1 text-right text-xs text-zinc-500">{prompt.length}/1800</div></div>
          {mode==="story"&&<div><label className="mb-2 block text-sm font-semibold">Number of scenes</label><select className="field" value={sceneCount} onChange={e=>setSceneCount(Number(e.target.value))}><option value={3}>3 scenes · Short story</option><option value={4}>4 scenes · Standard</option><option value={5}>5 scenes · Extended</option><option value={6}>6 scenes · Cinematic</option></select></div>}
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className="mb-2 block text-sm font-semibold"><Smartphone size={14} className="mr-1 inline"/> Video format</label><select className="field" value={aspectRatio} onChange={e=>setAspectRatio(e.target.value)}><option value="9:16">9:16 · Reels / TikTok</option><option value="16:9">16:9 · YouTube</option><option value="1:1">1:1 · Square</option></select></div>
            <div><label className="mb-2 block text-sm font-semibold"><AudioLines size={14} className="mr-1 inline"/> Narrator voice</label><select className="field" value={voice} onChange={e=>setVoice(e.target.value)}><option value="alloy">Alloy</option><option value="coral">Coral</option><option value="echo">Echo</option><option value="fable">Fable</option><option value="onyx">Onyx</option><option value="nova">Nova</option><option value="shimmer">Shimmer</option></select></div>
          </div>
          <div className="rounded-2xl border border-zinc-800 bg-black/25 p-4 space-y-3">
            <div className="flex items-center gap-2 font-semibold"><Layers size={16} className="text-red-400"/> Post-production tools</div>
            <div><label className="mb-2 block text-sm font-semibold"><Captions size={14} className="mr-1 inline"/> Captions / on-screen text</label><textarea className="field min-h-20" value={captionText} onChange={e=>setCaptionText(e.target.value)} placeholder="Optional captions or title text for the finished video…"/></div>
            <div><label className="mb-2 block text-sm font-semibold"><Music2 size={14} className="mr-1 inline"/> Background music <span className="font-normal text-zinc-500">(optional)</span></label><input className="field text-sm" type="file" accept="audio/mpeg,audio/mp3,audio/wav,audio/mp4,audio/aac" onChange={e=>setMusicFile(e.target.files?.[0]??null)}/>{musicFile&&<p className="text-xs text-zinc-500">{musicFile.name}</p>}</div>
            <button type="button" disabled={voiceBusy||(!story&&!prompt.trim())} onClick={async()=>{setVoiceBusy(true);setRenderMessage("");try{const text=story?.scenes.map(x=>x.narration).filter(Boolean).join(" ")||prompt;if(!text.trim())throw new Error("Add a prompt or create a story first.");const r=await fetch("/api/voice",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text,voice})});if(!r.ok){const d=await r.json().catch(()=>({}));throw new Error(d.error||"Voice generation failed.");}const blob=await r.blob();if(voiceUrl)URL.revokeObjectURL(voiceUrl);setVoiceUrl(URL.createObjectURL(blob));}catch(err){setRenderMessage(err instanceof Error?err.message:"Voice generation failed.");}finally{setVoiceBusy(false);}}} className="btn w-full border border-zinc-700 text-sm disabled:opacity-50">{voiceBusy?<Loader2 size={16} className="animate-spin"/>:<AudioLines size={16}/>} Generate AI voice-over</button>
            {voiceUrl&&<audio controls src={voiceUrl} className="w-full"/>}
          </div>
          <div><label className="mb-2 block text-sm font-semibold">Image reference <span className="font-normal text-zinc-500">(optional)</span></label><label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-zinc-700 bg-black/30 p-5 text-center hover:border-red-500">
            {preview?<img src={preview} alt="Reference preview" className="max-h-48 rounded-xl object-contain"/>:<ImagePlus className="text-red-400" size={28}/>}
            <span className="text-sm text-zinc-300">{file?file.name:"Upload a character or object image"}</span><span className="text-xs text-zinc-500">PNG, JPG or WEBP · max 10 MB</span>
            <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={e=>setFile(e.target.files?.[0]??null)}/>
          </label></div>
          <div className="rounded-xl border border-zinc-800 bg-black/30 p-3 text-xs text-zinc-400"><Film size={15} className="mr-2 inline text-red-400"/> Output target: {aspectRatio} · MP4. Video model controls clip duration and quality.</div>
          {message&&<p className="text-sm text-red-300">{message}</p>}
          <button disabled={busy||storyBusy||prompt.trim().length<8||(file!==null&&file.size>10*1024*1024)} className="btn btn-primary w-full py-3">{busy||storyBusy?<Loader2 className="animate-spin" size={18}/>:<Sparkles size={18}/>} {busy||storyBusy?"Working…":mode==="story"?"Create story & generate scenes":"Generate video"}</button>
        </form>
      </section>
      <section className="space-y-4">
        {story&&<div className="glass space-y-3 rounded-3xl p-5"><div><div className="text-xs font-bold tracking-widest text-red-400">YOUR STORY PLAN</div><h2 className="mt-1 text-xl font-black">{story.title}</h2><p className="mt-1 text-sm text-zinc-400">{story.logline}</p></div>{story.scenes.map(scene=><div key={scene.number} className="rounded-xl border border-zinc-800 bg-black/30 p-3"><div className="text-xs font-bold text-red-400">SCENE {scene.number}</div><div className="font-semibold">{scene.title}</div><p className="mt-1 text-sm text-zinc-400">{scene.description}</p>{scene.narration&&<p className="mt-2 text-xs italic text-zinc-500">Narration: {scene.narration}</p>}</div>)}</div>}
        <div className="glass space-y-3 rounded-3xl p-5">
          <div className="flex items-center gap-2"><Scissors size={17} className="text-red-400"/><h2 className="font-bold">Final video assembly</h2></div>
          <p className="text-sm text-zinc-400">When your scene clips are ready, select them in the creations list and combine them with your voice-over, music and captions into one MP4.</p>
          <button disabled={renderBusy||!jobs.some(j=>j.status==="succeeded"&&j.video_url)} onClick={async()=>{setRenderBusy(true);setRenderMessage("");try{let audioUrl:string|undefined;let backgroundUrl:string|undefined;if(voiceUrl){const blob=await fetch(voiceUrl).then(r=>r.blob());const path=`audio/voice-${crypto.randomUUID()}.mp3`;const {error}=await supabase.storage.from("assets").upload(path,blob,{contentType:"audio/mpeg"});if(error)throw error;audioUrl=supabase.storage.from("assets").getPublicUrl(path).data.publicUrl;}if(musicFile){const path=`audio/music-${crypto.randomUUID()}-${musicFile.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const {error}=await supabase.storage.from("assets").upload(path,musicFile,{contentType:musicFile.type});if(error)throw error;backgroundUrl=supabase.storage.from("assets").getPublicUrl(path).data.publicUrl;}const ready=jobs.filter(j=>j.status==="succeeded"&&j.video_url);const r=await fetch("/api/render",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({jobIds:ready.map(j=>j.id),audioUrl,backgroundUrl,captions:captionText,aspectRatio})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Could not start final render.");setRenderMessage(`Final render started · ${d.renderId}`);setRenderId(d.renderId||"");setRenderUrl("");}catch(err){setRenderMessage(err instanceof Error?err.message:"Render failed.");}finally{setRenderBusy(false);}}} className="btn btn-primary w-full disabled:opacity-50">{renderBusy?<Loader2 size={16} className="animate-spin"/>:<Clapperboard size={16}/>} Assemble finished MP4</button>
          {renderMessage&&<p className="text-xs text-zinc-300">{renderMessage}</p>}
          {renderId&&<button type="button" onClick={async()=>{try{const r=await fetch(`/api/render/${renderId}`);const d=await r.json();if(!r.ok)throw new Error(d.error||"Could not check render.");setRenderMessage(`Render status: ${d.status||"unknown"}`);if(d.url)setRenderUrl(d.url);}catch(err){setRenderMessage(err instanceof Error?err.message:"Could not check render.");}}} className="btn w-full border border-zinc-700 text-sm">Check render status</button>}
          {renderUrl&&<a href={renderUrl} target="_blank" rel="noreferrer" className="btn btn-primary w-full"><Download size={16}/> Open finished MP4</a>}
          <p className="text-[11px] text-zinc-600">Requires a configured Shotstack render API. Only completed clips are included.</p>
        </div>
        <div className="flex items-center justify-between"><div><h2 className="text-xl font-bold">Your creations</h2><p className="text-sm text-zinc-500">Recent generations</p></div><button onClick={loadJobs} className="text-xs text-zinc-400 hover:text-white">Refresh</button></div>
        {jobs.length===0?<div className="glass grid min-h-64 place-items-center rounded-3xl p-8 text-center"><div><Clapperboard className="mx-auto mb-3 text-zinc-600" size={34}/><p className="font-semibold">Your videos will appear here</p><p className="mt-1 text-sm text-zinc-500">Create your first video to get started.</p></div></div>:<div className="space-y-3">{jobs.map(job=><article key={job.id} className="glass space-y-3 rounded-2xl p-4"><div className="flex items-center justify-between gap-3"><span className="rounded-full bg-zinc-800 px-2 py-1 text-xs capitalize text-zinc-300">{job.status}</span><span className="text-xs text-zinc-500">{new Date(job.created_at).toLocaleString()}</span></div><p className="line-clamp-2 text-sm text-zinc-300">{job.prompt}</p>{job.video_url?<><video src={job.video_url} controls playsInline className="w-full rounded-xl bg-black"/><a className="btn btn-primary w-full" href={job.video_url} download><Download size={16}/> Download video</a></>:<button onClick={()=>refreshJob(job.id)} className="btn w-full border border-zinc-700 text-sm">Check generation status</button>}</article>)}</div>}
      </section>
    </div>
    <footer className="border-t border-zinc-900 px-5 py-6 text-center text-xs text-zinc-600">BENTLEY AI · Use only images you have permission to use.</footer>
  </main>;
}
